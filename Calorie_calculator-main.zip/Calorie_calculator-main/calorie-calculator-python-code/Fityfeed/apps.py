from django.apps import AppConfig


class FityfeedConfig(AppConfig):
    name = 'Fityfeed'
